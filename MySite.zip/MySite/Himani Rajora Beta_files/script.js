/* Variables */
var currentPage = "home";

/* Initialize Portfolio Slider with 8 elements */
$(window).load(function() {
	colorize();
	//slidr.create('slidr-img', {keyboard: true,theme: '#757575', transition: 'fade'}).add('h', ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'one']).start();
})
	
/* Colorize the title */		
function colorize()
	{
		setTimeout(function() {
			$('.a').addClass('col1');
		}, 500);
		setTimeout(function() {
			$('.b').addClass('col2');
		}, 1000);
		setTimeout(function() {
			$('.c').addClass('col3');
		}, 1500);
		setTimeout(function() {
			$('.d').addClass('col4');
		}, 2000);
		setTimeout(function() {
			$('.e').addClass('col5');
			}, 2500);
		setTimeout(function() {
			$('.f').addClass('col6');
			}, 3000);
		setTimeout(function() {
			$('.g').addClass('col7');
			}, 3500);
	}
		
function decolorize()
	{	
		$('.a').removeClass('col1');
		$('.b').removeClass('col2');
		$('.c').removeClass('col3');
		$('.d').removeClass('col4');
		$('.e').removeClass('col5');
		$('.f').removeClass('col6');
		$('.g').removeClass('col7');
	}
		
function showHome()
	{
		$('.aboutTitle,.desc,.workTitle,.workdesc,.contactTitle,.contactdesc,.typehere').addClass('animated bounceOutUp');
		$('.aboutimg,.workimg,.conForm,.phelp,#form-messages,.contactimg').addClass('animated bounceOutDown');
		$('#about,#work,#contact').removeClass('activelink');
			
		setTimeout(function() {
			$('.mainimg,.name').removeClass('hidden');
			$('.mainimg,.name').removeClass('animated bounceOutDown bounceOutUp');
			$('.name').addClass('animated bounceInDown');
			$('.mainimg').addClass('animated bounceInDown');
			setTimeout(function() {
				decolorize();
			}, 400);
			setTimeout(function() {
				colorize();
			}, 1000);
			}, 300);
			
		currentPage = "home";
	}

function showAbout()
	{
		$('.name,.workTitle,.workdesc,.contactTitle,.contactdesc,.typehere').addClass('animated bounceOutUp');
		$('.mainimg,.workimg,.conForm,.phelp,#form-messages,.contactimg').addClass('animated bounceOutDown');
		$('#about').addClass('activelink');
		$('#work,#contact').removeClass('activelink');
		window.scrollTo(0, 0);
		$('.guide').remove();
		
		setTimeout(function() {
			$('.aboutimg,.aboutTitle,.desc').removeClass('hidden');
			$('.aboutimg,.aboutTitle,.desc').removeClass('animated bounceOutDown bounceOutUp');
			$('.aboutimg,.aboutTitle,.desc').addClass('animated bounceInDown');
			setTimeout(function() {
				decolorize();
			}, 400);
			setTimeout(function() {
				colorize();
			}, 1000);
			}, 300);
			
		currentPage = "about";
	}
		
function showWork()
	{
		$('.name,.aboutTitle,.desc,.contactTitle,.contactdesc,.typehere').addClass('animated bounceOutUp');
		$('.mainimg,.aboutimg,.conForm,#form-messages,.contactimg').addClass('animated bounceOutDown');
		$('#work').addClass('activelink');
		$('#about,#contact').removeClass('activelink');
		window.scrollTo(0, 0);
		$('.guide').remove();
		
		setTimeout(function() {
			$('.workimg,.workTitle,.workdesc').removeClass('hidden');
			$('.workimg,.workTitle,.workdesc,.phelp').removeClass('animated bounceOutDown bounceOutUp');
			$('.workimg,.workTitle,.workdesc').addClass('animated bounceInDown');
			$('.phelp').addClass('animated bounceInUp');
			setTimeout(function() {
				decolorize();
			}, 400);
			setTimeout(function() {
				colorize();
			}, 1000);
			}, 300);
			
		currentPage = "work";
	}
	
function showContact()
	{
		$('.name,.aboutTitle,.desc,.workTitle,.workdesc').addClass('animated bounceOutUp');
		$('.mainimg,.aboutimg,.workimg,.phelp').addClass('animated bounceOutDown');
		$('#contact').addClass('activelink');
		$('#about,#work').removeClass('activelink');
		window.scrollTo(0, 0);
		$('.guide').remove();
		
		setTimeout(function() {
			$('.contactTitle,.contactdesc,.conForm,#form-messages,.contactimg,.typehere').removeClass('hidden');
			$('.contactTitle,.contactdesc,.conForm,#form-messages,.contactimg,.typehere').removeClass('animated bounceOutDown bounceOutUp');
			$('.contactTitle,.contactdesc,.conForm,#form-messages,.contactimg,.typehere').addClass('animated bounceInDown');
			setTimeout(function() {
				decolorize();
			}, 400);
			setTimeout(function() {
				colorize();
			}, 1000);
			}, 300);
			
		currentPage = "contact";
	}

document.onkeydown = checkKey;

function checkKey(e) {

    e = e || window.event;
	
	if(currentPage == "home") {
    	if (e.keyCode == '38') {
        	showContact(); // up arrow
		} else if (e.keyCode == '40') {
       		showAbout(); // down arrow
	   	}
	} else if(currentPage == "about") {
    	if (e.keyCode == '38') {
        	showHome(); // up arrow
		} else if (e.keyCode == '40') {
       		showWork(); // down arrow
	   	}
	} else if (currentPage == "work") {
    	if (e.keyCode == '38') {
        	showAbout(); // up arrow
		} else if (e.keyCode == '40') {
       		showContact(); // down arrow
	   	}
	} else if (currentPage == "contact"){
		if (e.keyCode == '38') {
        	showWork(); // up arrow
		} else if (e.keyCode == '40') {
       		showHome(); // down arrow
	   	}
	}
}

function removeit() {
	$('.typehere').remove();
}

// function validateEmail() { 
// 	var em = document.getElementById("email").value;
//     var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     return re.test(em);
// } 

// function clicksub() {
// 	$('#submithid').trigger( "click" );
// }

// var form = $('#ajax-contact');
// var formMessages = $('#form-messages');
	
// $(form).submit(function(event) {
// 	event.preventDefault();
    	
//     var formData = $(form).serialize();
	
// 	$.ajax({
// 		type: 'POST',
// 		url: $(form).attr('action'),
// 		data: formData
// 		}).done(function(response) {
// 				$(formMessages).removeClass('error');
// 				$(formMessages).addClass('success');
// 				setTimeout(function() {$(formMessages).text(response);$('#email').val('');$('#message').val('');},800);
// 				$('.conForm').addClass('animated bounceOutRight');
// 			}).fail(function(data) {
//     				$(formMessages).removeClass('success');
// 					$(formMessages).addClass('error');
// 					if (data.responseText !== '') {
// 						setTimeout(function() {$(formMessages).text(response);},800);
// 					} else {
// 						$(formMessages).text('Oops! An error occured and your message could not be sent.');
// 					}
// 				});
// });
